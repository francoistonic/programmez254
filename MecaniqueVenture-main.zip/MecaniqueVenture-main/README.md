# MecaniqueVenture
Projet fictif permettant de démontrer l'utilisation de NextJS sur un point de vue marketing pour les développeurs.
