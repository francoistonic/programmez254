# Sample Archives

This folder contains samples that are using deprecated classes or are not relevant in the current context.

Those samples are kept for compatibility reasons. **Do not use those in production with current images**.
