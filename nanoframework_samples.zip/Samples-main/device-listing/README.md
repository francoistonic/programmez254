﻿# Device listing generator

Run `dotnet run` on this project to auto-generate description in `/devices/README.md` and update the main `README.md`.

