﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("nanoFramework.SlowBlink")]
[assembly: AssemblyCompany("nanoFramework Contributors")]
[assembly: AssemblyProduct(".NET nanoframework nanoFramework.DependencyInjection Sample")]
[assembly: AssemblyCopyright("Copyright (c) .NET Foundation and Contributors")]

//////////////////////////////////////////////////////
// this assembly does NOT have a native counterpart //
//////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
[assembly: AssemblyNativeVersion("0.0.0.0")]
////////////////////////////////////////////////////////////////

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
