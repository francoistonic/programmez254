//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------

#include "NF_AwesomeLib.h"
#include "NF_AwesomeLib_NF_AwesomeLib_Math.h"

using namespace NF_AwesomeLib::NF_AwesomeLib;


double Math::NativeSuperComplicatedCalculation( double param0, HRESULT &hr )
{

    (void)param0;
    (void)hr;
    double retValue = 0;

    ////////////////////////////////
    // implementation starts here //


    // implementation ends here   //
    ////////////////////////////////

    return retValue;
}
