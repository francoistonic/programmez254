These projects are the Destktop equivalents of the nanoFramework ones.
Used to encode and decode with Base64.
