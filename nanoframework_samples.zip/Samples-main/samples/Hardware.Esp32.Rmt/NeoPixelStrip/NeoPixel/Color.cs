﻿namespace NeoPixel
{
	public class Color
	{
		public byte B;
		public byte G;
		public byte R;
	}
}
