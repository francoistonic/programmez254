These projects are the Destktop equivalents of the nanoFramework ones.
Used to cross check results.
