These projects are the Destktop equivalents of the nanoFramework ones.
Used to test number parsing.
