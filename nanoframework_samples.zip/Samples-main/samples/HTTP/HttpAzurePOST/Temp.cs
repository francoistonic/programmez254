﻿//
// Copyright (c) .NET Foundation and Contributors
// See LICENSE file in the project root for full license information.
//

namespace HttpSamples.HttpAzurePOST
{
    internal class Temp
    {
        public string DeviceID { get; set; }
        public string Temperature { get; set; }
    }
}