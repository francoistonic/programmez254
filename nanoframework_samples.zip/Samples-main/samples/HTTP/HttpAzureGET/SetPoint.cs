﻿//
// Copyright (c) .NET Foundation and Contributors
// See LICENSE file in the project root for full license information.
//

namespace HttpSamples.HttpAzureGET
{
    internal class SetPoint
    {
        public string DeviceID { get; set; }
        public string Value { get; set; }
        public string Temperature { get; set; }
    }
}