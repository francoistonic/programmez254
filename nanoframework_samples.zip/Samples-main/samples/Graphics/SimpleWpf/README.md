# Simple WPF

This contains an animated graphical menu with allows the selection of pages that demonstrates features of the limited WPF that's available in nanoFramework.

- Vertical Stack Panel
- Horizontal Stack panel
- Canvas panel
- Scrollable text Panel
- Free drawing panel

Requires the GPIO pins numbers to be defined for the Left, Right, Up, Down & Select keys, see Program.cs
