# Tetris Demo Game for nanoFramework

This was converted from an .net Micro Framework created on _(January 28th 2008)_

This is a demo application written to demonstrate different capabilities of .NET Micro Framework.
Windows Presentation Foundation, Extended Weak Reference for persistent storage etc.

It has been updated to work with nanoFramework (still Work in Progress).

This Tetris game became almost a benchmark demo for different hardware that supports .NET Micro Framework.

![Tetris](http://bansky.net/blog_stuff/images/tetris_tahoe.jpg)

![Tetris](http://bansky.net/blog_stuff/images/tetris_screenshots.png) 

Requires the GPIO pins numbers to be defined for the Left, Right, Up, Down & Select keys in the TetrisApp.cs

The number of Rows of blocks displayed and the size of the blocks can be adjusted to fit your screen in the UniverseView.cs and GameUniverse.cs
